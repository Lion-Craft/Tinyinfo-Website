# Tinyinfo
Lightweight System Info tool for Windows written in C# using .NET Framework 4.7.2

![grafik](https://github.com/Lion-Craft/Tinyinfo/assets/78223634/b74e825b-f37f-45d5-b7ba-6633adf13151)
