# Tinyinfo
Lightweight System Info tool for Windows written in C# using .NET Framework 4.7.2

![Preview](https://github.com/Lion-Craft/Tinyinfo/blob/master/Tinyinfo/Preview.png?raw=true)
